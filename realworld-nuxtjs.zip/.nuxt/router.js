import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _426f317e = () => interopDefault(import('..\\pages\\layout' /* webpackChunkName: "" */))
const _70e87ab6 = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _a741b71c = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _2b62bf1c = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _1e75030c = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _5a0ce4f8 = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _5dce3882 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _426f317e,
    children: [{
      path: "",
      component: _70e87ab6,
      name: "home"
    }, {
      path: "/login",
      component: _a741b71c,
      name: "login"
    }, {
      path: "/register",
      component: _a741b71c,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _2b62bf1c,
      name: "profile"
    }, {
      path: "/settings",
      component: _1e75030c,
      name: "settings"
    }, {
      path: "/editor",
      component: _5a0ce4f8,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _5dce3882,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
